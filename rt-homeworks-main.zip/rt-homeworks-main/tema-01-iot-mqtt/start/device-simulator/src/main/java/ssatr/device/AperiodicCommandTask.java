package ssatr.device;

import java.util.Locale;
import java.util.concurrent.BlockingQueue;

/**
 * TASK APERIODIC: execută comenzile primite de la business service.
 *
 * Comenzile sosesc oricând, pe MQTT, fără un interval minim între ele, și sunt
 * puse în coada commands. Fiecare comandă eliberează un job al taskului.
 * Comenzi care trebuie suportate:
 *
 *   SET_INTERVAL <ms>       schimbă perioada T a taskului periodic
 *   SET_THRESHOLD <valoare> schimbă pragul de alarmă
 *   RESET                   readuce senzorul la valoarea inițială
 *   STATUS                  raportează perioada și pragul curente
 *
 * După executarea fiecărei comenzi, device-ul publică pe Config.statusTopic(deviceId)
 * o confirmare: "deviceId;timestamp;text", de exemplu
 * "device-1;1727600000000;OK SET_INTERVAL 1000".
 */
public class AperiodicCommandTask implements Runnable {
    /** perioadă minimă acceptată, ca să nu inundăm brokerul partajat */
    static final long MIN_PERIOD_MS = 100;
    private final String deviceId;
    private final TemperatureSensor sensor;
    private final MqttConnection mqtt;
    private final BlockingQueue<String> commands;
    private final PeriodicTelemetryTask periodic;

    public AperiodicCommandTask(String deviceId, TemperatureSensor sensor, MqttConnection mqtt,
                                BlockingQueue<String> commands, PeriodicTelemetryTask periodic) {
        this.deviceId = deviceId;
        this.sensor = sensor;
        this.mqtt = mqtt;
        this.commands = commands;
        this.periodic = periodic;
    }

    @Override
    public void run() {
        // TODO 3: implementați taskul aperiodic:
        //   - preluați comenzile din coadă: commands.take()
        //   - separați numele comenzii de parametru: command.split(" ")
        //   - executați comanda (periodic.setPeriodMs(...), sensor.reset() etc.)
        //   - publicați confirmarea pe Config.statusTopic(deviceId)
        //   - o comandă necunoscută sau un parametru invalid nu trebuie să
        //     oprească taskul: publicați "ERROR <motiv>"
        periodic.setPeriodMs(2000);
        // Vezi exemplul exemple/01-taskuri/.../AperiodicTaskExample.java
        try {
            while (true) {
                String command = commands.take();   // în ordinea sosirii
                long arrival = System.nanoTime();

                String reply;
                try {
                    reply = execute(command.trim());
                } catch (RuntimeException e) {
                    // orice eroare neprevăzută: taskul continuă
                    reply = "ERROR " + e.getClass().getSimpleName();
                }

                // ';' este separatorul CSV, deci nu are voie în text
                reply = reply.replace(';', ',').replace('\n', ' ');
                mqtt.publish(Config.statusTopic(deviceId), deviceId + ";" + System.currentTimeMillis() + ";" + reply);

                long responseMs = (System.nanoTime() - arrival) / 1_000_000L;
                System.out.printf("      [aperiodic] \"%s\" -> %s  (R = %d ms)%n", command, reply, responseMs);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /** Execută o comandă și întoarce textul confirmării (OK ... sau ERROR ...). */
    private String execute(String command) {
        if (command.isEmpty()) {
            return "ERROR comanda goala";
        }

        String[] parts = command.split("\\s+");
        String name = parts[0].toUpperCase(Locale.ROOT);

        switch (name) {
            case "SET_INTERVAL": {
                if (parts.length != 2) {
                    return "ERROR SET_INTERVAL necesita un parametru: SET_INTERVAL <ms>";
                }
                long ms;
                try {
                    ms = Long.parseLong(parts[1]);
                } catch (NumberFormatException e) {
                    return "ERROR parametru invalid: " + parts[1];
                }
                if (ms < MIN_PERIOD_MS) {
                    return "ERROR perioada minima este " + MIN_PERIOD_MS + " ms";
                }
                periodic.setPeriodMs(ms);
                return "OK SET_INTERVAL " + ms;
            }
            case "SET_THRESHOLD": {
                if (parts.length != 2) {
                    return "ERROR SET_THRESHOLD necesita un parametru: SET_THRESHOLD <valoare>";
                }
                double value;
                try {
                    value = Double.parseDouble(parts[1]);
                } catch (NumberFormatException e) {
                    return "ERROR parametru invalid: " + parts[1];
                }
                if (Double.isNaN(value) || Double.isInfinite(value)) {
                    return "ERROR parametru invalid: " + parts[1];
                }
                periodic.setThreshold(value);
                return "OK SET_THRESHOLD " + String.format(Locale.US, "%.2f", value);
            }
            case "RESET":
                if (parts.length != 1) {
                    return "ERROR RESET nu are parametri";
                }
                sensor.reset();
                return "OK RESET";
            case "STATUS":
                if (parts.length != 1) {
                    return "ERROR STATUS nu are parametri";
                }
                return String.format(Locale.US, "OK STATUS period=%d threshold=%.2f",
                        periodic.getPeriodMs(), periodic.getThreshold());
            default:
                return "ERROR comanda necunoscuta: " + parts[0];
        }
    }
}

