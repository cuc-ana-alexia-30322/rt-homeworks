package ssatr.device;

import java.util.concurrent.BlockingQueue;
import java.util.Locale;


/**
 * TASK PERIODIC, cu perioada T = periodMs: fiecare job citește senzorul și
 * publică valoarea pe topic-ul de telemetrie.
 *
 * Dacă temperatura depășește pragul, taskul NU tratează el alarma, ci doar
 * semnalează un eveniment în coada alarmEvents. Alarma este tratată de
 * taskul sporadic.
 */
public class PeriodicTelemetryTask implements Runnable {

    private final String deviceId;
    private final TemperatureSensor sensor;
    private final MqttConnection mqtt;
    private final BlockingQueue<Double> alarmEvents;

    // volatile: sunt citite aici, dar modificate de taskul aperiodic (alt thread)
    private volatile long periodMs = 2000;
    private volatile double threshold = 28.0;
    //CONSTRUCTOR
    public PeriodicTelemetryTask(String deviceId, TemperatureSensor sensor, MqttConnection mqtt,
                                 BlockingQueue<Double> alarmEvents) {
        this.deviceId = deviceId;
        this.sensor = sensor;
        this.mqtt = mqtt;
        this.alarmEvents = alarmEvents;
    }
//TODO1:
    @Override
    public void run() {
            //date de intrare: c = 50ms T=2000ms
            //stabilim momentul eliberarii jobului curent de pe grila (5000000000ns = 50ms)
            long next = System.nanoTime(); //0

            while (!Thread.currentThread().isInterrupted()) {
                long jobStart = System.nanoTime();
                // 1. Citim temperatura
                // read() e synchronized, pentru că aperiodicul poate apela reset() în paralel
                double t = sensor.read();

                // 2. Construim mesajul de telemetrie
                long timestamp = System.currentTimeMillis(); // variabila stocheaza momentul actual pt ca avem nevoie de el in mesajul nostru

                String message = String.format(
                        Locale.US, // ia standardul din US
                        "%s;%d;%.2f",
                        deviceId,
                        timestamp,
                        t
                ); // scriem formatul pt mesajul nostru

                // 3. Publicăm temperatura
                mqtt.publish(
                        Config.telemetryTopic(deviceId),
                        message
                );

                // 4. Dacă temperatura depășește pragul,
                //    semnalăm evenimentul taskului sporadic
                if (t > threshold) {
                    alarmEvents.offer(t); // punem alarma in coada
                }

                // 5. Citim perioada actuală.
                //    Ea poate fi modificată de taskul aperiodic prin operatorul care trimite SET_INTERVAL 1000
                long currentPeriodMs = periodMs; //2000ms
                System.out.printf("[periodic] t=%.2f  L=%.2f ms%n", t, (jobStart - (next)) / 1_000_000.0);
                // 6. Calculăm următoarea eliberare pe grila periodică
                next += currentPeriodMs * 1_000_000L; // 0+2000ms

                // 7. Așteptăm doar timpul rămas până la următoarea eliberare
                long waitNs = next - System.nanoTime(); //2000-50=1950ms
                // aici zicem cat sa mai doarma pana la urmatoarea eliberare
                if (waitNs > 0) {
                    try {
                        long millis = waitNs / 1_000_000L; //e împărțire între long-uri, deci trunchiază
                        int nanos = (int) (waitNs % 1_000_000L);

                        Thread.sleep(millis, nanos);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            }
        }
//setteri si getteri pt ca atributele private sa poata fi accesate de catre alte clase
    public void setPeriodMs(long periodMs) {
        this.periodMs = periodMs;
    }

    public void setThreshold(double threshold) {
        this.threshold = threshold;
    }

    public long getPeriodMs() {
        return periodMs;
    }

    public double getThreshold() {
        return threshold;
    }
}
