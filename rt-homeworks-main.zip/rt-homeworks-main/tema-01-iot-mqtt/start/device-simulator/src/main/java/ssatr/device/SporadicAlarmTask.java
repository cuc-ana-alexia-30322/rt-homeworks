package ssatr.device;

import java.util.Locale;
import java.util.concurrent.BlockingQueue;

/**
 * TASK SPORADIC: tratează alarmele de temperatură.
 *
 * Evenimentele sosesc în coada alarmEvents (puse de taskul periodic).
 * Intervalul minim între sosiri este MIN_INTERARRIVAL_MS: între două eliberări
 * ale taskului (două alarme publicate) trebuie să treacă cel puțin atât.
 * Intervalul este impus de cod: evenimentele care sosesc mai des sunt
 * respinse, ca să nu fie inundat brokerul.
 *
 * Alegere: pragul din mesaj este citit din PeriodicTelemetryTask în momentul
 * publicării, nu transmis prin coadă. Astfel coada rămâne simplă (doar
 * temperatura), iar pragul publicat este cel în vigoare la eliberarea jobului.
 * Dacă SET_THRESHOLD ajunge exact între detectare și publicare (câteva ms),
 * mesajul conține noul prag; diferența este neglijabilă pentru acest sistem.
 */
public class SporadicAlarmTask implements Runnable {

    static final long MIN_INTERARRIVAL_MS = 5000;

    private final String deviceId;
    private final MqttConnection mqtt;
    private final BlockingQueue<Double> alarmEvents;
    private final PeriodicTelemetryTask periodic;

    public SporadicAlarmTask(String deviceId, MqttConnection mqtt, BlockingQueue<Double> alarmEvents, PeriodicTelemetryTask periodic) {
        this.deviceId = deviceId;
        this.mqtt = mqtt;
        this.alarmEvents = alarmEvents;
        this.periodic = periodic;
    }

    @Override
    public void run() {
        long lastRelease = 0;
        boolean released = false;   // a existat vreo eliberare până acum?

        try {
            while (true) {
                double temperature = alarmEvents.take();   // ia valoarea din coada si o stocheaza in variabila temperature
                long arrival = System.nanoTime();          // sosirea evenimentului, se actualizeaza cand evenimentul e extras din coada

                if (released) {
                    long sinceLastMs = (arrival - lastRelease) / 1_000_000L;
                    if (sinceLastMs < MIN_INTERARRIVAL_MS) {
                        System.out.printf(Locale.US,
                                "   [sporadic] alarmă RESPINSĂ (%.2f °C): au trecut doar %d ms (interval minim %d ms)%n",
                                temperature, sinceLastMs, MIN_INTERARRIVAL_MS);
                        continue; // sare direct la următoarea iterație a buclei while
                    }
                }
                lastRelease = arrival; // se actualizeaza doar atunci cand o alarma e acceptata
                released = true;

                double threshold = periodic.getThreshold();
                String message = String.format(Locale.US, "%s;%d;%.2f;%.2f",
                        deviceId, System.currentTimeMillis(), temperature, threshold);
                mqtt.publish(Config.alarmTopic(deviceId), message);

                long responseMs = (System.nanoTime() - arrival) / 1_000_000L;
                System.out.printf(Locale.US, "   [sporadic] ALARMĂ publicată: %.2f °C > prag %.2f  (R = %d ms)%n",
                        temperature, threshold, responseMs);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
